package com.auca.domain;


public enum Equalification {

	MASTER,
	PHD,
	PROFESSOR
}
